Model predictions from the paper
==========
Here we place predictions from the six different models presented in Table 5 in the EMNLP 2017 paper:

- m1.json: hard-LR, dep. feats.
- m2.json: hard-LR, n-gram feats.
- m3.json: hard-LR, all feats.
- m4.json: hard-CNN
- m5.json: soft-CNN (EM)
- m6.json: soft-LR (EM)
